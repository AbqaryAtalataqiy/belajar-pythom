class Person:
    def __init__(self, name, age):
        self.name = name
      
    def getinfo(self):
      print("This person's name is", self.name)

    nits = ""
      
class Student(Person):
  def__init__(self, name, nis) :
    super().__init__(name)
    self.nis = nis

  def study(self, subject):
    print("This student is studying", subject)

#person1 = Person("John", 0123456)
#person1.getinfo()
#Student.study("mary")

class Doctor(Person):
  reg_number = ""

  def __init__(self, name, reg_number):

  def getInfo(self):

  def diagnose(self, patient):

  def treat(self, patient):

Student1 = Student("John", 123456)
Student1.getInfo()
Student1.study("Nath")