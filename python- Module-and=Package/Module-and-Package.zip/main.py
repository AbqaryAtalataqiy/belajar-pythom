from mymodule import area_of_square

area_of_square(10)
area_of_triangle(10, 12)