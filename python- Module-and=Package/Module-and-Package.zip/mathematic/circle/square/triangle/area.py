def triangle_area(base, height):
  result = 1/2 * base * height
  text = f"Area of The triangle is {result}"
  print(text)