def square_area(side):
  result = side * side
  text = f"Area of The square is {result}"
  print(text)