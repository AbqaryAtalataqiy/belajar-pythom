def circle_area(radius):
  pi = 22/7
  result = pi * radius * radius
  text = f"Area of The circle is {result}"
  print(text)