def square_perimeter(side):
  result = 4 * side
  text = f"Perimeter of The square is {result}"
  print(text)
  
def circle_perimeter(radius):
  pi = 22/7
  result = 2 * pi * radius
  text = f"Perimeter of The circle is {result}"
  print(text)
  
def triangle_perimeter(base, height):
  result = 2 * (base + height)
  text = f"Perimeter of The triangle is {result}"
  print(text)