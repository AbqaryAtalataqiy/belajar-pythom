class Animal:
  name = "mumu" # propreties / attribute
  color = "white"

  def makeSound(self, sound):
      print(f"{self.name} is {sound}")
     
  def eat(self, food):
      print(f"{self, name} is eating {food}")

  def Sleep(self):
      pritn(f"{self.name} is sleeping")
    
cat = Animal()
cat.name = "Bravo"
cat.makeSound("meowing")